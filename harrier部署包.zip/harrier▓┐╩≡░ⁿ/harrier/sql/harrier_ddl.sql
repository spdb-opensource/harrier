

-- 导出  表 harrier_uat.dy_job_arrange 结构
CREATE TABLE IF NOT EXISTS `dy_job_arrange` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台名',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '应用系统',
  `job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业名',
  `deploy_yaml` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '作业编排参数',
  `task_status` int unsigned NOT NULL DEFAULT '1' COMMENT '变更状态：1->新增 2->变更 3->下线',
  `process_status` int unsigned NOT NULL DEFAULT '1' COMMENT '任务状态：1->待投产 2->投产失败 3->投产成功',
  `sync_status` int unsigned DEFAULT NULL COMMENT '同步状态：0->正常线上开发无需同步 1->成功 2->失败',
  `start_date` datetime DEFAULT NULL COMMENT '进入dispatcher状态的时间',
  `end_date` datetime DEFAULT NULL COMMENT '开始执行时间',
  `version` int unsigned NOT NULL DEFAULT '0' COMMENT '版本号',
  `des` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_id` (`platform`,`systems`,`job`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='变更管理配置表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.dy_job_attributes 结构
CREATE TABLE IF NOT EXISTS `dy_job_attributes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台名',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '应用系统',
  `job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业名',
  `job_name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '作业名中文',
  `job_type` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业类型：D 每天执行(来信号文件就执行)，W 每周执行（触发里面检测信号文件来的星期几），M 每月执行（检测触发里面是否有对应的日期 0为月末，C ：定时执行',
  `stream_type` tinyint NOT NULL DEFAULT '0' COMMENT '作业触发类型',
  `job_date` date DEFAULT NULL COMMENT '最后执行作业信号文件日期 yyyy-MM-dd',
  `last_status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '作业运行状态：Ready Done Runing Failed Pending Dispatcher',
  `task_status` int unsigned NOT NULL DEFAULT '1' COMMENT '任务状态：1->新增 2->变更 3->下线 4->上线完成',
  `multi_batch` int unsigned NOT NULL DEFAULT '0' COMMENT '批次号： 0非多批次作业 非0多批次作业',
  `time_window` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '00:01-23:59 ' COMMENT '窗口执行时间 小时单位 0|23 0-23 点为执行窗口时间',
  `virtual_enable` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '作业是否执虚->1：虚作业 ，0：非虚作业 默认：1执虚作业,不再执行脚本。',
  `priority` int NOT NULL DEFAULT '100' COMMENT '作业执行优先级 开发范围 0-1000 1000最高',
  `call_again_max_num` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '自动重调最大次数',
  `call_again_wait_sec` tinyint unsigned NOT NULL DEFAULT '60',
  `check_frequency` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否检测时间：检测来信号文件间隔时间 0：不检测，1检测  针对D W M Y',
  `check_time_trigger` bit(1) NOT NULL DEFAULT b'0' COMMENT '检测是否采用时间触发：0：不检测，1检测 关联uds_job_time_trigger表',
  `check_stream_self` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否启用stream file 检测触发 0不采用 1采用',
  `dep_job` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '依赖作业_批次，配置多个依赖使用","分隔；例如：A@0,B@0',
  `job_step` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '执行脚本,stepnum@cmd@dir@name@type使用","分隔',
  `job_frequency` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '作业频度',
  `offset_day` tinyint NOT NULL DEFAULT '0' COMMENT '偏移天数+1开始时间日期加1天,-1开始时间日期减1天',
  `ignore_error` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否忽视错误现场 0，不忽视；1是忽视',
  `des` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_id` (`platform`,`systems`,`job`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='作业属性信息表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.m_alarm 结构
CREATE TABLE IF NOT EXISTS `m_alarm` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '应用',
  `job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业',
  `code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '告警码',
  `alarm_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '告警类型',
  `alarm_level` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '告警级别',
  `times` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '告警时间',
  `alarm_status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'HIDE' COMMENT '告警状态',
  `src_content` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '告警原始内容',
  `src_param` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '告警内容参数',
  `title` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '标题',
  `content` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '告警内容',
  `notice_group_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '告警通知用户组',
  `notice_count` int unsigned NOT NULL DEFAULT '0' COMMENT '告警发送当前次数',
  `notice_times` int unsigned NOT NULL DEFAULT '0' COMMENT '通知次数',
  `notice_cyce` int unsigned NOT NULL DEFAULT '10' COMMENT '通知周期',
  `notice_send_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '告警最后发送时间',
  `operation_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '处理方式',
  `operation_time` datetime DEFAULT NULL COMMENT '处理时间',
  `operation_user` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '处理用户',
  `remark` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `platform` (`platform`,`systems`,`job`,`code`),
  KEY `alarm_code` (`code`),
  KEY `alarm_status` (`alarm_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='告警记录表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.m_alarm_config 结构
CREATE TABLE IF NOT EXISTS `m_alarm_config` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '应用',
  `code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '告警码',
  `job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '作业',
  `def_status` int NOT NULL DEFAULT '0' COMMENT '告警默认状态',
  `notice_times` int unsigned NOT NULL DEFAULT '0' COMMENT '通知次数',
  `notice_cycle` int unsigned DEFAULT '10' COMMENT '通知间隔分',
  `notice_group_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '通知用户组',
  `build` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否生成告警信息',
  `is_enable` bit(1) NOT NULL DEFAULT b'0' COMMENT '0--有效 1--无效',
  `update_user` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '更新用户',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `remark` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alarm_code` (`platform`,`systems`,`code`,`job`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='告警配置表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.m_alarm_msg 结构
CREATE TABLE IF NOT EXISTS `m_alarm_msg` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `platform` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `systems` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '告警ID',
  `alarm_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '告警类型',
  `alarm_level` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '告警级别',
  `title` varchar(68) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '通知标题',
  `content` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '通知内容',
  `remark` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alarm_code` (`code`,`platform`,`systems`),
  KEY `platform` (`platform`,`systems`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='告警消息配置表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.m_alarm_send_queue 结构
CREATE TABLE IF NOT EXISTS `m_alarm_send_queue` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `alarm_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '告警id',
  `group_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '联系组',
  `send_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '发送状态',
  `send_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '发送类型',
  `send_params` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `title` varchar(68) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '标题',
  `content` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '发送内容',
  `file_path` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '附件路径',
  `expcetion` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '发送异常',
  `send_time` datetime DEFAULT NULL COMMENT '发送时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '生成时间',
  `remark` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `status` (`send_status`),
  KEY `alarm_id` (`alarm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='告警发送';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.m_alarm_user_group 结构
CREATE TABLE IF NOT EXISTS `m_alarm_user_group` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '应用',
  `group_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '组名',
  `send_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '发送类型',
  `send_params` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '发送参数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_name`),
  KEY `platform` (`platform`,`systems`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='告警联系人组';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.m_dictionary 结构
CREATE TABLE IF NOT EXISTS `m_dictionary` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `dic_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '字典类型',
  `dic_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'key',
  `dic_name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '字典名',
  `dic_value` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT 'value',
  `dic_desc` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_dictionary` (`dic_code`,`dic_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='字典表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.m_menu 结构
CREATE TABLE IF NOT EXISTS `m_menu` (
  `menu_id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `menu_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '菜单名',
  `parent_menu_id` int unsigned NOT NULL DEFAULT '0' COMMENT '父菜单id',
  `menu_no` int unsigned NOT NULL COMMENT '菜单序号',
  `menu_url` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '菜单链接',
  `menu_icon_url` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '1',
  `menu_flag` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '菜单标识：0--按钮 1--菜单',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_user` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '创建用户',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_user` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '更新用户',
  `is_enable` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '1--有效 0--无效',
  `remark` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='菜单表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.m_operat_log 结构
CREATE TABLE IF NOT EXISTS `m_operat_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '操作用户',
  `operat_type` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '操作类型',
  `operat` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '操作',
  `job` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '相关作业',
  `ip` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'IP',
  `operat_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `operat_content` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '操作内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='操作日志表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.m_role 结构
CREATE TABLE IF NOT EXISTS `m_role` (
  `role_id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `role_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '角色名',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_user` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '创建用户',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_user` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '更新用户',
  `is_enable` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否有效：0--有效 1--无效',
  `remark` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='角色表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.m_role_menu 结构
CREATE TABLE IF NOT EXISTS `m_role_menu` (
  `role_id` int unsigned NOT NULL,
  `menu_id` int unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='角色菜单关系表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.m_user 结构
CREATE TABLE IF NOT EXISTS `m_user` (
  `user_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '用户',
  `user_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '姓名',
  `user_pwd` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '密码',
  `user_email` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '用户邮箱',
  `user_phone` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '用户手机号',
  `emp_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '员工工号',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_user` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '创建用户',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_user` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '更新用户',
  `is_expired` bit(1) NOT NULL DEFAULT b'0' COMMENT '0--未过期 1--过期',
  `is_locked` bit(1) NOT NULL DEFAULT b'0' COMMENT '0--未锁定 1--已锁定',
  `is_enable` bit(1) NOT NULL DEFAULT b'0' COMMENT '0--有效 1--无效',
  `is_single` bit(1) NOT NULL DEFAULT b'0' COMMENT '1--单用户 0--多用户在线',
  `is_modify_pwd` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否需要修改密码：0--否 1--是',
  `pwd_wrong_count` int unsigned NOT NULL DEFAULT '0' COMMENT '密码输入错误次数',
  `remark` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_code` (`user_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='用户表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.m_user_role 结构
CREATE TABLE IF NOT EXISTS `m_user_role` (
  `user_id` bigint unsigned NOT NULL,
  `role_id` int unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='用户角色关系表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.m_user_systems 结构
CREATE TABLE IF NOT EXISTS `m_user_systems` (
  `user_id` bigint unsigned NOT NULL COMMENT '角色id',
  `systems_id` int unsigned NOT NULL COMMENT '应用',
  `permissions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT 'R,W',
  PRIMARY KEY (`user_id`,`systems_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='角色平台关系表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_ job_self_signal 结构
CREATE TABLE IF NOT EXISTS `uds_ job_self_signal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `signal` varchar(256) NOT NULL DEFAULT '',
  `platform` varchar(10) NOT NULL,
  `systems` varchar(10) NOT NULL,
  `job` varchar(128) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `batch` int NOT NULL DEFAULT '0',
  `job_date` date NOT NULL,
  `evns` varchar(256) NOT NULL DEFAULT '',
  `params` varchar(256) NOT NULL DEFAULT '',
  `useful` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`),
  KEY `platform` (`platform`,`systems`,`job`,`job_date`,`batch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_complement 结构
CREATE TABLE IF NOT EXISTS `uds_complement` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `com_name` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '补数名称',
  `start_time` date NOT NULL COMMENT '开始日期',
  `end_time` date NOT NULL COMMENT '结束日期',
  `last_status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'READY' COMMENT '补数状态',
  `batch_range` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '0' COMMENT '批次范围',
  `server_name_range` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '服务器范围',
  `max_run_job` int NOT NULL DEFAULT '1' COMMENT '作业并行数',
  `des` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='作业信息表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_job 结构
CREATE TABLE IF NOT EXISTS `uds_job` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台名',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '应用系统',
  `job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业名',
  `last_status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'Ready' COMMENT '作业运行状态',
  `job_date` date NOT NULL DEFAULT '2099-01-01',
  `next_job_date` date NOT NULL DEFAULT '2099-01-01',
  `server_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `multi_batch` int unsigned NOT NULL DEFAULT '0' COMMENT '批次号： 0非多批次作业 非0多批次作业',
  `pending_time` datetime NOT NULL DEFAULT '2020-02-02 00:00:00' COMMENT '进入pending状态的时间',
  `dispatcher_time` datetime NOT NULL DEFAULT '2020-02-02 00:00:00' COMMENT '进入dispatcher状态的时间',
  `start_time` datetime NOT NULL DEFAULT '2020-02-02 00:00:00' COMMENT '开始执行时间',
  `end_time` datetime NOT NULL DEFAULT '2020-02-02 00:00:00' COMMENT '结束时间时间',
  `num_times` bigint unsigned NOT NULL DEFAULT '0' COMMENT '作业运行次数',
  `call_again_num` int unsigned NOT NULL DEFAULT '0' COMMENT '重调次数',
  `stream_type` tinyint NOT NULL DEFAULT '0' COMMENT '触发类型',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `des` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_id` (`platform`,`systems`,`job`),
  KEY `job` (`job`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='作业信息表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_job_complement 结构
CREATE TABLE IF NOT EXISTS `uds_job_complement` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `complement_id` bigint unsigned NOT NULL,
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台名',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '应用系统',
  `job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业名',
  `job_date` date DEFAULT NULL,
  `last_status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'READY' COMMENT '作业运行状态',
  `server_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '服务器名',
  `multi_batch` int NOT NULL COMMENT '批次号',
  `start_time` datetime NOT NULL COMMENT '开始执行时间',
  `end_time` datetime NOT NULL COMMENT '结束时间时间',
  `des` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_id` (`complement_id`,`platform`,`systems`,`job`),
  CONSTRAINT `FK_uds_job_complement_uds_complement` FOREIGN KEY (`complement_id`) REFERENCES `uds_complement` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='作业信息表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_job_config 结构
CREATE TABLE IF NOT EXISTS `uds_job_config` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台名',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '应用系统',
  `job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业名',
  `job_name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '作业名中文',
  `job_type` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'D' COMMENT '作业类型：D M C ',
  `offset_day` tinyint NOT NULL DEFAULT '0' COMMENT '偏移天数+1开始时间日期加1天,-1开始时间日期减1天',
  `time_window` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '00:01-23:59 ' COMMENT '窗口执行时间 小时单位 0|23 0-23 点为执行窗口时间',
  `virtual_enable` bit(1) NOT NULL DEFAULT b'1' COMMENT '作业是否执虚->1：虚作业 ，0：非虚作业 执虚作业,不再执行脚本。',
  `priority` int NOT NULL DEFAULT '100' COMMENT '作业执行优先级 开发范围 0-1000  1000最高',
  `call_again_max_num` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '自动重调最大次数',
  `call_again_wait_sec` tinyint unsigned NOT NULL DEFAULT '60',
  `count_batch` int unsigned NOT NULL DEFAULT '1' COMMENT '总批次数',
  `batch_conversion` int unsigned NOT NULL DEFAULT '1' COMMENT '跳皮转换，根据模除为0执行，除取整为批次',
  `check_frequency` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否检测时间：检测来信号文件间隔时间 0：不检测，1：检测  针对D W M Y',
  `check_time_trigger` bit(1) NOT NULL DEFAULT b'0' COMMENT '检测是否采用时间触发：0：不检测，1检测  关联uds_job_time_trigger表',
  `check_stream_self` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否启用stream file 检测触发 0不采用 1采用',
  `ignore_error` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否忽视错误现场 0，不忽视 1：忽视',
  `check_weight` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否检测权重',
  `is_enable` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否执行 1：执行 0：不执行 默认：1',
  `des` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_id` (`platform`,`systems`,`job`),
  KEY `job` (`job`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='作业信息表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_job_date_frequency 结构
CREATE TABLE IF NOT EXISTS `uds_job_date_frequency` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '唯一ID',
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '系统',
  `job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业',
  `is_enable` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否使用 1使用 0不启用',
  `crontab` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '0,0,0,*,*,?,*',
  `des` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`),
  KEY `platform` (`platform`,`systems`,`job`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='检测信号文件来的时间是否符合要求，作业的间隔时间，及频率控制';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_job_dependency 结构
CREATE TABLE IF NOT EXISTS `uds_job_dependency` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '系统',
  `job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业',
  `dep_platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '依赖 平台',
  `dep_system` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '依赖 系统',
  `dep_job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '依赖 作业',
  `dep_batch` int unsigned NOT NULL DEFAULT '0' COMMENT '单批次触发多批次，依赖批次号',
  `is_enable` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否使用',
  `des` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`),
  KEY `dep_job_2_job` (`dep_system`,`dep_platform`,`dep_job`),
  KEY `job_2_dep_job` (`platform`,`systems`,`job`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='作业依赖表 ';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_job_record 结构
CREATE TABLE IF NOT EXISTS `uds_job_record` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `complement_id` bigint unsigned NOT NULL DEFAULT '0',
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '应用',
  `job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业名',
  `job_type` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业类型',
  `server_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `job_date` date NOT NULL COMMENT '作业时间',
  `last_status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业最后状态 （ Done 和 Failed）',
  `pending_time` datetime NOT NULL COMMENT '作业进入pending状态时间',
  `dispatcher_time` datetime NOT NULL COMMENT '作业分发时间',
  `start_time` datetime NOT NULL DEFAULT '1970-01-01 00:00:00' COMMENT '开始时间',
  `end_time` datetime NOT NULL DEFAULT '1970-01-01 00:00:00' COMMENT '结束时间',
  `stream_type` tinyint NOT NULL DEFAULT '0' COMMENT '触发方式-> 0随意触发，1定时，2信号文件，3:HTTP，4:依赖满足触发',
  `virtual_enable` bit(1) NOT NULL DEFAULT b'0',
  `multi_batch` int NOT NULL DEFAULT '0' COMMENT '批次号',
  `num_times` bigint NOT NULL DEFAULT '0' COMMENT '执行次数',
  PRIMARY KEY (`id`),
  KEY `idx_end_time` (`end_time`),
  KEY `job` (`job`,`num_times`),
  KEY `platform` (`platform`,`systems`,`job`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='uds 作业记录信息记录 与 etl_job';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_job_source 结构
CREATE TABLE IF NOT EXISTS `uds_job_source` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `signal` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '信号文件',
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '系统',
  `job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业',
  `is_enable` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `src_signal` (`signal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='信号文件表/历史';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_job_step 结构
CREATE TABLE IF NOT EXISTS `uds_job_step` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '平台名',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '系统名',
  `job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业名',
  `step_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'T' COMMENT '脚本类型(perl,python)',
  `step_num` tinyint unsigned NOT NULL COMMENT '执行步骤',
  `oper_cmd` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '执行命令',
  `script_path` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '脚本路径',
  `parameter` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '执行参数 空格 分割',
  `environments` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '环境变量 KEY=VALUE KEY=VALUE',
  `work_dir` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '工作路径',
  `update_time` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `is_enable` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否可以使用 0：不可以 1：可以；默认1',
  `des` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注信息',
  PRIMARY KEY (`id`),
  UNIQUE KEY `job` (`platform`,`systems`,`job`,`step_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='执行脚本的配置表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_job_step_record 结构
CREATE TABLE IF NOT EXISTS `uds_job_step_record` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `job_record_id` bigint NOT NULL,
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '系统',
  `job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业',
  `num_times` bigint unsigned NOT NULL COMMENT '执行次数',
  `step_num` tinyint unsigned NOT NULL,
  `return_code` int NOT NULL DEFAULT '0' COMMENT '返回CODE',
  `address` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `environments` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `cmd` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `script_path` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '脚本路径',
  `parameter` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '参数',
  `start_time` datetime NOT NULL COMMENT '开始时间',
  `end_time` datetime NOT NULL COMMENT '结束时间',
  `log_path` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '日志路径',
  PRIMARY KEY (`id`),
  KEY `job` (`platform`,`systems`,`job`,`num_times`,`step_num`),
  KEY `job_record_id` (`job_record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='作业脚本执行的记录';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_job_time_trigger 结构
CREATE TABLE IF NOT EXISTS `uds_job_time_trigger` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `platform` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台',
  `systems` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '系统',
  `job` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业',
  `start_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '下次执行时间',
  `end_time` datetime NOT NULL DEFAULT '2099-01-01 00:00:01' COMMENT '停止时间',
  `crontab` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '0,0,0,*,*,?,*' COMMENT 'crontab表   秒，分，时，天，月，周，年',
  `is_enable` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否启用；0不启用 1启用',
  `des` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT ' ',
  PRIMARY KEY (`id`),
  UNIQUE KEY `job` (`platform`,`systems`,`job`,`id`),
  KEY `start_time` (`start_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='定时和触发作业表：模仿 crontab 的方式 ';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_job_weight 结构
CREATE TABLE IF NOT EXISTS `uds_job_weight` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `platform` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台',
  `systems` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '应用',
  `job` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '作业名',
  `limit_type` int NOT NULL COMMENT '资源类型',
  `conf_value` int NOT NULL DEFAULT '0' COMMENT '占用资源数',
  `desc` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `limit` (`platform`,`systems`,`job`,`limit_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='作业权重配置表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_job_weight_limit 结构
CREATE TABLE IF NOT EXISTS `uds_job_weight_limit` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `limit_type` int NOT NULL COMMENT '类型类型',
  `limit_value` int NOT NULL DEFAULT '0' COMMENT '资源上限',
  `server_ids` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '*' COMMENT '机器id',
  `time_winds` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '00:01-23:59' COMMENT '时间窗口',
  `des` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`),
  KEY `limit` (`limit_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='作业权重表限制表';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_server 结构
CREATE TABLE IF NOT EXISTS `uds_server` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `server_role_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '对外服务名',
  `server_role_name_group` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '对内服务组名',
  `node_cluster_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '集群名',
  `server_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '服务器名字',
  `ip` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '服务器iP',
  `port` int NOT NULL DEFAULT '9696' COMMENT '服务通讯端口',
  `last_start` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '上次启动时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `last_end` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '关闭时间',
  `is_enable` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否启用 需要加载',
  `para` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '参数',
  `des` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT ' ' COMMENT '描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`,`port`),
  KEY `server_role_name` (`server_role_name`,`server_role_name_group`,`node_cluster_type`,`server_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='服务节点信息，配置信息。';

-- 数据导出被取消选择。


-- 导出  表 harrier_uat.uds_system 结构
CREATE TABLE IF NOT EXISTS `uds_system` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `platform` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '平台',
  `systems` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '*' COMMENT '系统(*针对所有系统)',
  `max_run_job` smallint unsigned NOT NULL DEFAULT '30' COMMENT '该应用的最大运行作业数',
  `selects` tinyint NOT NULL DEFAULT '1',
  `selects_pro` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `use_platform` bit(1) NOT NULL DEFAULT b'1' COMMENT '1:使用平台数据 0自己单独数据',
  `server_role_name_group` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `des` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenant_platform_systems` (`platform`,`systems`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='记录平台系统';

-- 数据导出被取消选择。
