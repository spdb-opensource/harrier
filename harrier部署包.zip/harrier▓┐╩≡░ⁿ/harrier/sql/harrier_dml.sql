
REPLACE INTO `m_dictionary` (`id`, `dic_code`, `dic_key`, `dic_name`, `dic_value`, `dic_desc`) VALUES
	(1, 'jobType', 'D', '作业类型', '日作业', 'test'),
	(2, 'jobType', 'C', '', '定时作业', ''),
	(3, 'jobType', 'W', NULL, '周作业', NULL),
	(4, 'jobType', 'M', NULL, '月作业', NULL);

REPLACE INTO `m_menu` (`menu_id`, `menu_name`, `parent_menu_id`, `menu_no`, `menu_url`, `menu_icon_url`, `menu_flag`, `create_time`, `create_user`, `update_time`, `update_user`, `is_enable`, `remark`) VALUES
	(1, '作业管理', 0, 1, '/job', 'iconfont icon-a-184-renwu iconfont icon-a-184-renwu', 0, '2022-02-25 01:54:36', 'admin', '2022-02-25 01:54:36', 'admin', 1, NULL),
	(2, '告警管理', 0, 2, '/alarm', 'iconfont icon-Notification-on iconfont icon-Notification-on', 0, '2022-02-24 09:23:56', 'admin', '2022-02-24 09:23:56', 'admin', 1, NULL),
	(3, '节点管理', 0, 3, '/serverManager', 'iconfont icon-a-120-peizhi iconfont icon-a-120-peizhi', 0, '2022-02-24 09:23:56', 'admin', '2022-02-24 09:23:56', 'admin', 1, NULL),
	(4, '系统管理', 0, 4, '/systemsetting', 'ivu-icon ivu-icon-spdb-shezhi iconfont icon-shezhi', 0, '2022-02-24 09:23:56', 'admin', '2022-02-24 09:23:56', 'test', 1, 'test'),
	(5, '作业列表', 1, 11, 'jobList', '1', 1, '2022-02-25 02:20:09', 'admin', '2022-02-25 02:20:09', 'admin', 1, NULL),
	(6, '新增作业', 1, 12, 'addJob', '1', 1, '2022-02-25 02:20:09', 'admin', '2022-02-25 02:20:09', 'admin', 1, NULL),
	(7, '自定义sql查询', 1, 13, 'sqlQuery', '1', 1, '2022-02-25 02:20:09', 'admin', '2022-02-25 02:20:09', 'admin', 1, NULL),
	(8, '告警规则配置', 2, 21, 'amarlConfig', '1', 1, '2022-02-25 02:22:09', 'admin', '2022-02-25 02:22:09', 'admin', 1, NULL),
	(9, '平台告警配置', 2, 22, 'amarlPlatformConfig', '1', 1, '2022-02-25 02:22:09', 'admin', '2022-02-25 02:22:09', 'admin', 1, NULL),
	(10, '作业告警配置', 2, 23, 'amarlJobConfig', '1', 1, '2022-02-25 02:22:09', 'admin', '2022-02-25 02:22:09', 'admin', 1, NULL),
	(11, '邮件短信配置', 2, 24, 'amarlSendConfig', '1', 1, '2022-02-25 02:22:09', 'admin', '2022-02-25 02:22:09', 'admin', 1, NULL),
	(12, '告警联系组配置', 2, 25, 'amarlUserGroup', '1', 1, '2022-02-25 02:22:09', 'admin', '2022-02-25 02:22:09', 'admin', 1, NULL),
	(13, '节点管理', 3, 31, 'serverConfig', '1', 1, '2022-02-25 02:24:17', 'admin', '2022-02-25 02:24:17', 'admin', 1, NULL),
	(14, '文件管理', 3, 32, 'fileManage', '1', 1, '2022-02-25 02:24:17', 'admin', '2022-02-25 02:24:17', 'admin', 1, NULL),
	(15, '用户管理', 4, 41, 'user', '1', 1, '2022-02-25 02:25:14', 'admin', '2022-02-25 02:25:14', 'admin', 1, NULL),
	(16, '角色管理', 4, 42, 'role', '1', 1, '2022-02-25 02:25:14', 'admin', '2022-02-25 02:25:14', 'admin', 1, NULL),
	(17, '菜单管理', 4, 43, 'menu', '1', 1, '2022-02-25 02:25:14', 'admin', '2022-02-25 02:25:14', 'admin', 1, NULL),
	(18, '系统设置', 4, 44, 'sysConfig', '1', 1, '2022-02-25 02:25:14', 'admin', '2022-02-25 02:25:14', 'admin', 1, NULL),
	(19, '资源类型管理', 4, 45, 'weightType', '1', 1, '2022-02-25 02:25:14', 'admin', '2022-02-25 02:25:14', 'admin', 1, NULL),
	(20, '作业资源管理', 4, 46, 'jobWeight', '1', 1, '2022-02-25 02:25:14', 'admin', '2022-02-25 02:25:14', 'admin', 1, NULL),
	(21, '操作日志', 4, 47, 'operatLog', '1', 1, '2022-02-25 02:25:14', 'admin', '2022-02-25 02:25:14', 'admin', 1, NULL),
	(22, '平台管理', 4, 48, 'platformConfig', '1', 1, '2022-02-25 02:25:14', 'admin', '2022-02-25 02:25:14', 'admin', 1, NULL),
	(23, '工作流管理', 0, 1, '/workflow', 'ivu-icon ivu-icon-spdb-a-zu11 iconfont icon-a-zu11', 0, '2022-05-28 15:19:07', 'test', '2022-05-28 15:19:07', 'test', 1, '工作流管理/查询/新增/删除/修改'),
	(24, 'workflowDefinition', 64, 2, '工作流', '1', 1, '2022-05-28 15:21:40', 'test', '2022-05-28 15:21:40', 'test', 1, '工作流总控');
