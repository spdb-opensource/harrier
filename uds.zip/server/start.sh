#/dev/null 为Linux 空设备（黑洞）
#echo $! >./uds.lock
cd `dirname $0`;
APP_NAME='uds-0.0.1-SNAPSHOT.jar'
pid=$(ps -ef | grep java | grep ${APP_NAME} | awk '{print $2}')
if [ -z "${pid}" ];then
	echo "${APP_NAME} is  not exist start runing"
	sleep 3
	nohup java -jar -server -Xmx2g -Xms2g -Xmn512m -XX:+HeapDumpOnOutOfMemoryError ./uds-0.0.1-SNAPSHOT.jar >/dev/null 2>&1 & 
	if [ $? -eq 0 ];then
		echo "start ${APP_NAME} success ";
	else 
		echo "start ${APP_NAME} error ";
	fi
	echo "please check log, exec  [tail -f ./logs/app.log]  ";
else
	echo "${APP_NAME} is  running .pid =${pid} " ;
fi 
