cd `dirname $0`;
APP_NAME='uds-0.0.1-SNAPSHOT.jar';
pid=$(ps -ef | grep java | grep ${APP_NAME} | awk '{print $2}');
if [ -z "${pid}" ];then
	echo "${APP_NAME} is  not exist";
else
	echo "${APP_NAME} is  running .pid =${pid}";
	sleep 3;
	kill ${pid};
	if [ $? -eq 0 ];
	then 
		echo "kill ${APP_NAME} success ";
		echo "please check log, exec [ tail -f ./logs/app.log ] ";
	fi
fi
